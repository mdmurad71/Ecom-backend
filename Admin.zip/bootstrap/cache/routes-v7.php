<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kFP2t0EiEv0m2S3E',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/loginByMobile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gVjWMQCGwy8DCAeC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/CategoryListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ppRmO0IpUmNAowb3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/SendSliderInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::762wPu4YWIWtv21U',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/categoryGetData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0mqnZuV5HLABYm2F',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/SendSiteInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N0r0o3t3qPu2tVUL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/addToCart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZmFivQZ91atotFKx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/Order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uzOufWgKyIX06Nhy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p0ZWDLbU4IVKpyuo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/HomeSummary' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C5Y9RSjbm8tWFXnD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SignIn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/OnSignIn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bI1DjCrRGNCRrjkw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/OnLogOut' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TV5mjzb0VOPlv9QG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/VisitorListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mYw4fJ7DjleW24LI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/VisitorListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z5J19OPJ4QdDFhDr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/NotificationListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mY3sWqHxlHrLwucm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/NotificationListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W8YnBiQaFFvVRI9R',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CreateNotification' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qxl2gaF91cns7F8X',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ContactListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e8aSPg8BSPskYMIV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ContactListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4v4f0xcXQMkcCYiq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ContactListDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q63rpgU1TO93M0xG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/AdminListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ImT2iysnFma6b3BX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/AdminListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Lw4CbJKa3rW40eD2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/AdminAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AF80icdhGyym6PbI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/AdminListDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vjcOHrjEfUE7FpX7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/AboutPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BuxLYG98l9EMdPg0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/TermsPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YvHiTwiMicLX3vII',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/PolicyPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fUU1Lxjxb4Ua4ic9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/PurchasePage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fUPRF9oyRRSPonTI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/AddressPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3zFGMKWQZ5Zr5BUV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/AboutCompanyPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Uhypfcz9Gl9dtfG8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/MobileAppPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dLVn1vVkRQ4fVH86',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SocialPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K8Rdonp9eECG9DCc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/GetSiteInfoDetails' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BsHH4MjrDluN0hDi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/UpdateSiteInfo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rV0BQCtdeQhCgWnw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/siteSEO' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::671urfwQ56VB24FQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/GetSEODetails' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mt4MQ4elPRqOfjvh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/UpdateSEODetails' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iUjoOzGQDOOlLlJh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeSEOIMG' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hQQCz2y7ygeFQYZb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CategoryListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a5MA5LnaLpwAhYue',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CategoryListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o78NoAF4Y4as18r3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CategoryAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oATYEqyuUf8Y2Doo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CategoryDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SIUPFXnBKXLt3Cun',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeCategoryImage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HrECJLVlWebZoGxU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/GetCategoryName' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ETjO8p4onhfoXWbz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CategoryNameEdit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dEobyT0BhryET1sp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SubCategoryListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yVP8n4sRp8PyOqba',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SubCategoryListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SzMP9EupNEVCz0ZF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SubCategoryAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0tda6TQbNsqg7JGu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SubCategoryDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DtgLfXNEHhyAX9wy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/GetSubCategoryEditData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wF1GGLTrELYw0Jq2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SubCategoryNameEdit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hBMz8n3PMqlrXwNI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BrandListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pGh9YAn6bXZX3AQf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BrandListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Du72tAgZ52MtFiti',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BrandAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZPEPk3Xgl4cPLLJM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/BrandDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8jnKGxq0dDn7ZyXr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeBrandImage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0xYrFv4yDrpT2EXy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JqdOSjXgYIC3y8de',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DiEPpjDFSmnjGVVe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/GetCategoryList' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hEauaHcgLpJNGTSX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/GetSubCategoryAsCategory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uyTg8KA0A9PvLxCt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductListAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HBm6ZFbitawBk3px',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductListDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fi3InG50mg1rRBfv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeProductListImage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0m9TEKGPmKxNwtcZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductListEditData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::df9CmiSa6HRoWrFV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductListDataEdit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tgFKDrCJ6oGdvcmk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::83Idv00oybLygCT4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y6AXeKnwkIFPxcmU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cGslDHtv0N5FVVX9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsWithOneImg' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bGKN9VAyLLwuvbZf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsWithTwoImg' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KjxEwGfPl15LyCD7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsWithThreeImg' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f71qLhdnDGU6CRIU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yxQmTutcDFk9VQuO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsEditData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZBPDohkry1A4C38q',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductDetailsDataEdit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hRT3sWirN2CraZu5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductImageEditData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q5Yx0hSDzWXQcTdn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeProductImageOne' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dHqxirexmqsePuE0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeProductImageTwo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ey8XegsDKi7M9jBt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeProductImageThree' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eiM5IO4zpiGTfhb4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeProductImageFour' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X4uDAS2KyjXgfJml',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ShopPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z8W9b5zu7pO5K0HV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ShopData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NIqpySjhdGQhfnBJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ShopAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YGpR4AE090xz0wcf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ShopDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h3s4deoWAMucVeFe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeShopLogo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0zZe4CAgbhQiUgUw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SliderListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VBgoeRUNL71uhdK8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SliderListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jmIKds312vfSfJ8w',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/GetProductCode' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZkOgvTklBckYRx42',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SliderAdd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Yny6kSu3rovmyVd9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SliderDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4J9miQ0GNCJfsfiU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ChangeSliderImage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ok8OT2lbRrIxz8hy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SliderListEditData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::THb5q2q6HNzjKddS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/SliderDataEdit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nP51XJLKPDgmUP5y',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CustomOrderPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nuOl4DK02TXIxZKA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CustomOrderData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xT0uMWHo6b6N3Ncg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/CustomOrderDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HyA2kzHFvT3oJN2U',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/OtpListPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::leQ4KTLm1wTDebeJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/OtpListData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lUlhpUxvugAPUxR7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductOrderPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2cuWoqfoZRW5LGrO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductOrderData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pyFyZXob34C6RfPM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductOrderDetailsData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5OxiMSfQGVlMKFs4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductOrderDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DAfQecW8g2VHb0ko',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductOrderStatusEdit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bHtpx6hxVvZastO6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductOrderInvoiceData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K1bB7vldOHcqJTY2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductReviewPage' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cRZOnA3tHfvDEWBE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductReviewData' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fDG2K89CeK4exxg4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ProductReviewDelete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1PHpzD5xobXn7bgq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/smsTest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xTSYJWkY652asLiu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/PaymentTest' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cgf6CXVbmhieZjo1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/example1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jIXJUeYpzQdb5teQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/example2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dFaMJX7OEA7dexhI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pay' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dE5vjtpsag5mzKBJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pay-via-ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CYjm6Dl0yazOj2jR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/success' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ogMKdjK2mVQcC1kc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/fail' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RZQJGDDV549efHSC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cancel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OGMV40z5FvxzMTH0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/ipn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VCatoY85il9ajHJv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|Product(?|ShortListByRemark/([^/]++)(*:51)|DetailsByCode/([^/]++)(*:80))|Cart(?|Count/([^/]++)(*:109)|Details/([^/]++)(*:133)|Item(?|Plus/([^/]++)/([^/]++)/([^/]++)(*:179)|Minus/([^/]++)/([^/]++)/([^/]++)(*:219)))|RemoveCartList/([^/]++)(*:252)|OrderListByUser/([^/]++)(*:284)|addFav/([^/]++)/([^/]++)(*:316)|favList/([^/]++)(*:340)|removeFavItem/([^/]++)/([^/]++)(*:379)))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9V0a9KDQZLmNYg3q',
          ),
          1 => 
          array (
            0 => 'remark',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      80 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yvJZP57GJTtqVbxl',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      109 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bilHsLhQcvitbBk0',
          ),
          1 => 
          array (
            0 => 'mobile',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      133 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZhOLzg43Ha9cSQgk',
          ),
          1 => 
          array (
            0 => 'mobile',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      179 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZpmOvnffMQjvglhd',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'quantity',
            2 => 'price',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      219 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9q9LtUVVpYbflLYp',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'quantity',
            2 => 'price',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      252 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zrGteUuzGhMxMPmM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      284 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IqqdpG7rl3pJ4YN7',
          ),
          1 => 
          array (
            0 => 'mobile',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6VJiv9et8obcH56l',
          ),
          1 => 
          array (
            0 => 'code',
            1 => 'mobile',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      340 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sv8ywOkog6HQFisQ',
          ),
          1 => 
          array (
            0 => 'mobile',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      379 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4xvKWKiK5kNLXACO',
          ),
          1 => 
          array (
            0 => 'mobile',
            1 => 'code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::kFP2t0EiEv0m2S3E' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":291:{@JY0DSdbVQzl7sPcx8Hcj7ZiwYmLb8CGnwyPFC2IgV4I=.a:5:{s:3:"use";a:0:{}s:8:"function";s:79:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000018b1b33b0000000057d4a121";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::kFP2t0EiEv0m2S3E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gVjWMQCGwy8DCAeC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/loginByMobile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\OTPController@loginByMobile',
        'controller' => 'App\\Http\\Controllers\\OTPController@loginByMobile',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::gVjWMQCGwy8DCAeC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ppRmO0IpUmNAowb3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/CategoryListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@CategoryListData',
        'controller' => 'App\\Http\\Controllers\\CategoryController@CategoryListData',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ppRmO0IpUmNAowb3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::762wPu4YWIWtv21U' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/SendSliderInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@sliderInfo',
        'controller' => 'App\\Http\\Controllers\\SliderController@sliderInfo',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::762wPu4YWIWtv21U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0mqnZuV5HLABYm2F' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/categoryGetData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@categoryGetData',
        'controller' => 'App\\Http\\Controllers\\CategoryController@categoryGetData',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::0mqnZuV5HLABYm2F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::N0r0o3t3qPu2tVUL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/SendSiteInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@GetSiteInfoDetails',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@GetSiteInfoDetails',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::N0r0o3t3qPu2tVUL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9V0a9KDQZLmNYg3q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ProductShortListByRemark/{remark}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@productListByRemark',
        'controller' => 'App\\Http\\Controllers\\ProductListController@productListByRemark',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::9V0a9KDQZLmNYg3q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yvJZP57GJTtqVbxl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ProductDetailsByCode/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@productDetails',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@productDetails',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::yvJZP57GJTtqVbxl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZmFivQZ91atotFKx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/addToCart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductCartController@addToCart',
        'controller' => 'App\\Http\\Controllers\\ProductCartController@addToCart',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZmFivQZ91atotFKx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bilHsLhQcvitbBk0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/CartCount/{mobile}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductCartController@CartCount',
        'controller' => 'App\\Http\\Controllers\\ProductCartController@CartCount',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::bilHsLhQcvitbBk0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZhOLzg43Ha9cSQgk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/CartDetails/{mobile}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductCartController@CartDetails',
        'controller' => 'App\\Http\\Controllers\\ProductCartController@CartDetails',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZhOLzg43Ha9cSQgk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZpmOvnffMQjvglhd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/CartItemPlus/{id}/{quantity}/{price}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductCartController@CartItemPlus',
        'controller' => 'App\\Http\\Controllers\\ProductCartController@CartItemPlus',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZpmOvnffMQjvglhd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9q9LtUVVpYbflLYp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/CartItemMinus/{id}/{quantity}/{price}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductCartController@CartItemMinus',
        'controller' => 'App\\Http\\Controllers\\ProductCartController@CartItemMinus',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::9q9LtUVVpYbflLYp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zrGteUuzGhMxMPmM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/RemoveCartList/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductCartController@RemoveCartList',
        'controller' => 'App\\Http\\Controllers\\ProductCartController@RemoveCartList',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::zrGteUuzGhMxMPmM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uzOufWgKyIX06Nhy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/Order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductCartController@PostOrder',
        'controller' => 'App\\Http\\Controllers\\ProductCartController@PostOrder',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::uzOufWgKyIX06Nhy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IqqdpG7rl3pJ4YN7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/OrderListByUser/{mobile}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductOrderController@OrderListByUser',
        'controller' => 'App\\Http\\Controllers\\ProductOrderController@OrderListByUser',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::IqqdpG7rl3pJ4YN7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6VJiv9et8obcH56l' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/addFav/{code}/{mobile}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\FavouriteController@addFav',
        'controller' => 'App\\Http\\Controllers\\FavouriteController@addFav',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::6VJiv9et8obcH56l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::sv8ywOkog6HQFisQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/favList/{mobile}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\FavouriteController@favList',
        'controller' => 'App\\Http\\Controllers\\FavouriteController@favList',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::sv8ywOkog6HQFisQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4xvKWKiK5kNLXACO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/removeFavItem/{mobile}/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\FavouriteController@removeFavItem',
        'controller' => 'App\\Http\\Controllers\\FavouriteController@removeFavItem',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::4xvKWKiK5kNLXACO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::p0ZWDLbU4IVKpyuo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@HomePage',
        'controller' => 'App\\Http\\Controllers\\HomeController@HomePage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::p0ZWDLbU4IVKpyuo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::C5Y9RSjbm8tWFXnD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'HomeSummary',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\HomeController@HomeSummary',
        'controller' => 'App\\Http\\Controllers\\HomeController@HomeSummary',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::C5Y9RSjbm8tWFXnD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'SignIn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminLoginController@SignIn',
        'controller' => 'App\\Http\\Controllers\\AdminLoginController@SignIn',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bI1DjCrRGNCRrjkw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'OnSignIn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminLoginController@OnSignIn',
        'controller' => 'App\\Http\\Controllers\\AdminLoginController@OnSignIn',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bI1DjCrRGNCRrjkw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TV5mjzb0VOPlv9QG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'OnLogOut',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminLoginController@OnLogOut',
        'controller' => 'App\\Http\\Controllers\\AdminLoginController@OnLogOut',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::TV5mjzb0VOPlv9QG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mYw4fJ7DjleW24LI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'VisitorListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VisitorListController@VisitorListPage',
        'controller' => 'App\\Http\\Controllers\\VisitorListController@VisitorListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mYw4fJ7DjleW24LI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::z5J19OPJ4QdDFhDr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'VisitorListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VisitorListController@VisitorListData',
        'controller' => 'App\\Http\\Controllers\\VisitorListController@VisitorListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::z5J19OPJ4QdDFhDr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mY3sWqHxlHrLwucm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'NotificationListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NotificationListController@NotificationListPage',
        'controller' => 'App\\Http\\Controllers\\NotificationListController@NotificationListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mY3sWqHxlHrLwucm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::W8YnBiQaFFvVRI9R' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'NotificationListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NotificationListController@NotificationListData',
        'controller' => 'App\\Http\\Controllers\\NotificationListController@NotificationListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::W8YnBiQaFFvVRI9R',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qxl2gaF91cns7F8X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'CreateNotification',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NotificationListController@CreateNotification',
        'controller' => 'App\\Http\\Controllers\\NotificationListController@CreateNotification',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::qxl2gaF91cns7F8X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::e8aSPg8BSPskYMIV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ContactListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ContactListController@ContactListPage',
        'controller' => 'App\\Http\\Controllers\\ContactListController@ContactListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::e8aSPg8BSPskYMIV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4v4f0xcXQMkcCYiq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ContactListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ContactListController@ContactListData',
        'controller' => 'App\\Http\\Controllers\\ContactListController@ContactListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::4v4f0xcXQMkcCYiq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::q63rpgU1TO93M0xG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ContactListDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ContactListController@ContactListDelete',
        'controller' => 'App\\Http\\Controllers\\ContactListController@ContactListDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::q63rpgU1TO93M0xG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ImT2iysnFma6b3BX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'AdminListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminListController@AdminListPage',
        'controller' => 'App\\Http\\Controllers\\AdminListController@AdminListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ImT2iysnFma6b3BX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Lw4CbJKa3rW40eD2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'AdminListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminListController@AdminListData',
        'controller' => 'App\\Http\\Controllers\\AdminListController@AdminListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Lw4CbJKa3rW40eD2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AF80icdhGyym6PbI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'AdminAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminListController@AdminAdd',
        'controller' => 'App\\Http\\Controllers\\AdminListController@AdminAdd',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::AF80icdhGyym6PbI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vjcOHrjEfUE7FpX7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'AdminListDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminListController@AdminListDelete',
        'controller' => 'App\\Http\\Controllers\\AdminListController@AdminListDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::vjcOHrjEfUE7FpX7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BuxLYG98l9EMdPg0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'AboutPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@AboutPage',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@AboutPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::BuxLYG98l9EMdPg0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YvHiTwiMicLX3vII' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'TermsPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@TermsPage',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@TermsPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YvHiTwiMicLX3vII',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fUU1Lxjxb4Ua4ic9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'PolicyPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@PolicyPage',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@PolicyPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fUU1Lxjxb4Ua4ic9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fUPRF9oyRRSPonTI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'PurchasePage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@PurchasePage',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@PurchasePage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fUPRF9oyRRSPonTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3zFGMKWQZ5Zr5BUV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'AddressPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@AddressPage',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@AddressPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3zFGMKWQZ5Zr5BUV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Uhypfcz9Gl9dtfG8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'AboutCompanyPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@AboutCompanyPage',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@AboutCompanyPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Uhypfcz9Gl9dtfG8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dLVn1vVkRQ4fVH86' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'MobileAppPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@MobileAppPage',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@MobileAppPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dLVn1vVkRQ4fVH86',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::K8Rdonp9eECG9DCc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'SocialPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@SocialPage',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@SocialPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::K8Rdonp9eECG9DCc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BsHH4MjrDluN0hDi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'GetSiteInfoDetails',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@GetSiteInfoDetails',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@GetSiteInfoDetails',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::BsHH4MjrDluN0hDi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rV0BQCtdeQhCgWnw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'UpdateSiteInfo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteInfoController@UpdateSiteInfo',
        'controller' => 'App\\Http\\Controllers\\SiteInfoController@UpdateSiteInfo',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::rV0BQCtdeQhCgWnw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::671urfwQ56VB24FQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'siteSEO',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteSEOController@SiteSEOPage',
        'controller' => 'App\\Http\\Controllers\\SiteSEOController@SiteSEOPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::671urfwQ56VB24FQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mt4MQ4elPRqOfjvh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'GetSEODetails',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteSEOController@GetSEODetails',
        'controller' => 'App\\Http\\Controllers\\SiteSEOController@GetSEODetails',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mt4MQ4elPRqOfjvh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iUjoOzGQDOOlLlJh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'UpdateSEODetails',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SiteSEOController@UpdateSEODetails',
        'controller' => 'App\\Http\\Controllers\\SiteSEOController@UpdateSEODetails',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::iUjoOzGQDOOlLlJh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hQQCz2y7ygeFQYZb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeSEOIMG',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\admin\\ChangeImageController@ChangeSEOIMG',
        'controller' => 'App\\Http\\Controllers\\admin\\ChangeImageController@ChangeSEOIMG',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hQQCz2y7ygeFQYZb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::a5MA5LnaLpwAhYue' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'CategoryListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@CategoryListPage',
        'controller' => 'App\\Http\\Controllers\\CategoryController@CategoryListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::a5MA5LnaLpwAhYue',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::o78NoAF4Y4as18r3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'CategoryListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@CategoryListData',
        'controller' => 'App\\Http\\Controllers\\CategoryController@CategoryListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::o78NoAF4Y4as18r3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oATYEqyuUf8Y2Doo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'CategoryAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@CategoryAdd',
        'controller' => 'App\\Http\\Controllers\\CategoryController@CategoryAdd',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::oATYEqyuUf8Y2Doo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SIUPFXnBKXLt3Cun' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'CategoryDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@CategoryDelete',
        'controller' => 'App\\Http\\Controllers\\CategoryController@CategoryDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SIUPFXnBKXLt3Cun',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HrECJLVlWebZoGxU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeCategoryImage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@ChangeCategoryImage',
        'controller' => 'App\\Http\\Controllers\\CategoryController@ChangeCategoryImage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::HrECJLVlWebZoGxU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ETjO8p4onhfoXWbz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'GetCategoryName',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@GetCategoryName',
        'controller' => 'App\\Http\\Controllers\\CategoryController@GetCategoryName',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ETjO8p4onhfoXWbz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dEobyT0BhryET1sp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'CategoryNameEdit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@CategoryNameEdit',
        'controller' => 'App\\Http\\Controllers\\CategoryController@CategoryNameEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dEobyT0BhryET1sp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yVP8n4sRp8PyOqba' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'SubCategoryListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryListPage',
        'controller' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::yVP8n4sRp8PyOqba',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SzMP9EupNEVCz0ZF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'SubCategoryListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryListData',
        'controller' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SzMP9EupNEVCz0ZF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0tda6TQbNsqg7JGu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'SubCategoryAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryAdd',
        'controller' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryAdd',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0tda6TQbNsqg7JGu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DtgLfXNEHhyAX9wy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'SubCategoryDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryDelete',
        'controller' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::DtgLfXNEHhyAX9wy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wF1GGLTrELYw0Jq2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'GetSubCategoryEditData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SubCategoryController@GetSubCategoryEditData',
        'controller' => 'App\\Http\\Controllers\\SubCategoryController@GetSubCategoryEditData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::wF1GGLTrELYw0Jq2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hBMz8n3PMqlrXwNI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'SubCategoryNameEdit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryNameEdit',
        'controller' => 'App\\Http\\Controllers\\SubCategoryController@SubCategoryNameEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hBMz8n3PMqlrXwNI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pGh9YAn6bXZX3AQf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'BrandListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BrandController@BrandListPage',
        'controller' => 'App\\Http\\Controllers\\BrandController@BrandListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::pGh9YAn6bXZX3AQf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Du72tAgZ52MtFiti' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'BrandListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BrandController@BrandListData',
        'controller' => 'App\\Http\\Controllers\\BrandController@BrandListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Du72tAgZ52MtFiti',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZPEPk3Xgl4cPLLJM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'BrandAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BrandController@BrandAdd',
        'controller' => 'App\\Http\\Controllers\\BrandController@BrandAdd',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ZPEPk3Xgl4cPLLJM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8jnKGxq0dDn7ZyXr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'BrandDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BrandController@BrandDelete',
        'controller' => 'App\\Http\\Controllers\\BrandController@BrandDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::8jnKGxq0dDn7ZyXr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0xYrFv4yDrpT2EXy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeBrandImage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BrandController@ChangeBrandImage',
        'controller' => 'App\\Http\\Controllers\\BrandController@ChangeBrandImage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0xYrFv4yDrpT2EXy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::JqdOSjXgYIC3y8de' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ProductListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@ProductListPage',
        'controller' => 'App\\Http\\Controllers\\ProductListController@ProductListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::JqdOSjXgYIC3y8de',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DiEPpjDFSmnjGVVe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ProductListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@ProductListData',
        'controller' => 'App\\Http\\Controllers\\ProductListController@ProductListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::DiEPpjDFSmnjGVVe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hEauaHcgLpJNGTSX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'GetCategoryList',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@GetCategoryList',
        'controller' => 'App\\Http\\Controllers\\ProductListController@GetCategoryList',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hEauaHcgLpJNGTSX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uyTg8KA0A9PvLxCt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'GetSubCategoryAsCategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@GetSubCategoryAsCategory',
        'controller' => 'App\\Http\\Controllers\\ProductListController@GetSubCategoryAsCategory',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::uyTg8KA0A9PvLxCt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HBm6ZFbitawBk3px' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductListAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@ProductListAdd',
        'controller' => 'App\\Http\\Controllers\\ProductListController@ProductListAdd',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::HBm6ZFbitawBk3px',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Fi3InG50mg1rRBfv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductListDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@ProductListDelete',
        'controller' => 'App\\Http\\Controllers\\ProductListController@ProductListDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Fi3InG50mg1rRBfv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0m9TEKGPmKxNwtcZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeProductListImage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@ChangeProductListImage',
        'controller' => 'App\\Http\\Controllers\\ProductListController@ChangeProductListImage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0m9TEKGPmKxNwtcZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::df9CmiSa6HRoWrFV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductListEditData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@ProductListEditData',
        'controller' => 'App\\Http\\Controllers\\ProductListController@ProductListEditData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::df9CmiSa6HRoWrFV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tgFKDrCJ6oGdvcmk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductListDataEdit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductListController@ProductListDataEdit',
        'controller' => 'App\\Http\\Controllers\\ProductListController@ProductListDataEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tgFKDrCJ6oGdvcmk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::83Idv00oybLygCT4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ProductDetailsPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsPage',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::83Idv00oybLygCT4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::y6AXeKnwkIFPxcmU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ProductDetailsData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsData',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::y6AXeKnwkIFPxcmU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cGslDHtv0N5FVVX9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductDetailsAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsAdd',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsAdd',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::cGslDHtv0N5FVVX9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bGKN9VAyLLwuvbZf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductDetailsWithOneImg',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsWithOneImg',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsWithOneImg',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bGKN9VAyLLwuvbZf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KjxEwGfPl15LyCD7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductDetailsWithTwoImg',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsWithTwoImg',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsWithTwoImg',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KjxEwGfPl15LyCD7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::f71qLhdnDGU6CRIU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductDetailsWithThreeImg',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsWithThreeImg',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsWithThreeImg',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::f71qLhdnDGU6CRIU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yxQmTutcDFk9VQuO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductDetailsDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsDelete',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::yxQmTutcDFk9VQuO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZBPDohkry1A4C38q' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductDetailsEditData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsEditData',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsEditData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ZBPDohkry1A4C38q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hRT3sWirN2CraZu5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductDetailsDataEdit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsDataEdit',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductDetailsDataEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hRT3sWirN2CraZu5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::q5Yx0hSDzWXQcTdn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductImageEditData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ProductImageEditData',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ProductImageEditData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::q5Yx0hSDzWXQcTdn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dHqxirexmqsePuE0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeProductImageOne',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ChangeProductImageOne',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ChangeProductImageOne',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dHqxirexmqsePuE0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ey8XegsDKi7M9jBt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeProductImageTwo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ChangeProductImageTwo',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ChangeProductImageTwo',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ey8XegsDKi7M9jBt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eiM5IO4zpiGTfhb4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeProductImageThree',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ChangeProductImageThree',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ChangeProductImageThree',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::eiM5IO4zpiGTfhb4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::X4uDAS2KyjXgfJml' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeProductImageFour',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductDetailsController@ChangeProductImageFour',
        'controller' => 'App\\Http\\Controllers\\ProductDetailsController@ChangeProductImageFour',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::X4uDAS2KyjXgfJml',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Z8W9b5zu7pO5K0HV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ShopPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@ShopPage',
        'controller' => 'App\\Http\\Controllers\\ShopController@ShopPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Z8W9b5zu7pO5K0HV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NIqpySjhdGQhfnBJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ShopData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@ShopData',
        'controller' => 'App\\Http\\Controllers\\ShopController@ShopData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::NIqpySjhdGQhfnBJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YGpR4AE090xz0wcf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ShopAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@ShopAdd',
        'controller' => 'App\\Http\\Controllers\\ShopController@ShopAdd',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YGpR4AE090xz0wcf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::h3s4deoWAMucVeFe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ShopDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@ShopDelete',
        'controller' => 'App\\Http\\Controllers\\ShopController@ShopDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::h3s4deoWAMucVeFe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0zZe4CAgbhQiUgUw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeShopLogo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@ChangeShopLogo',
        'controller' => 'App\\Http\\Controllers\\ShopController@ChangeShopLogo',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0zZe4CAgbhQiUgUw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VBgoeRUNL71uhdK8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'SliderListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@SliderListPage',
        'controller' => 'App\\Http\\Controllers\\SliderController@SliderListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::VBgoeRUNL71uhdK8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jmIKds312vfSfJ8w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'SliderListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@SliderListData',
        'controller' => 'App\\Http\\Controllers\\SliderController@SliderListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::jmIKds312vfSfJ8w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZkOgvTklBckYRx42' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'GetProductCode',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@GetProductCode',
        'controller' => 'App\\Http\\Controllers\\SliderController@GetProductCode',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ZkOgvTklBckYRx42',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Yny6kSu3rovmyVd9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'SliderAdd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@SliderAdd',
        'controller' => 'App\\Http\\Controllers\\SliderController@SliderAdd',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Yny6kSu3rovmyVd9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4J9miQ0GNCJfsfiU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'SliderDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@SliderDelete',
        'controller' => 'App\\Http\\Controllers\\SliderController@SliderDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::4J9miQ0GNCJfsfiU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ok8OT2lbRrIxz8hy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ChangeSliderImage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@ChangeSliderImage',
        'controller' => 'App\\Http\\Controllers\\SliderController@ChangeSliderImage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Ok8OT2lbRrIxz8hy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::THb5q2q6HNzjKddS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'SliderListEditData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@SliderListEditData',
        'controller' => 'App\\Http\\Controllers\\SliderController@SliderListEditData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::THb5q2q6HNzjKddS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nP51XJLKPDgmUP5y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'SliderDataEdit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SliderController@SliderDataEdit',
        'controller' => 'App\\Http\\Controllers\\SliderController@SliderDataEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::nP51XJLKPDgmUP5y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nuOl4DK02TXIxZKA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'CustomOrderPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomOrderController@CustomOrderPage',
        'controller' => 'App\\Http\\Controllers\\CustomOrderController@CustomOrderPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::nuOl4DK02TXIxZKA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xT0uMWHo6b6N3Ncg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'CustomOrderData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomOrderController@CustomOrderData',
        'controller' => 'App\\Http\\Controllers\\CustomOrderController@CustomOrderData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::xT0uMWHo6b6N3Ncg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HyA2kzHFvT3oJN2U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'CustomOrderDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomOrderController@CustomOrderDelete',
        'controller' => 'App\\Http\\Controllers\\CustomOrderController@CustomOrderDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::HyA2kzHFvT3oJN2U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::leQ4KTLm1wTDebeJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'OtpListPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\OTPController@OtpListPage',
        'controller' => 'App\\Http\\Controllers\\OTPController@OtpListPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::leQ4KTLm1wTDebeJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lUlhpUxvugAPUxR7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'OtpListData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\OTPController@OtpListData',
        'controller' => 'App\\Http\\Controllers\\OTPController@OtpListData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::lUlhpUxvugAPUxR7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2cuWoqfoZRW5LGrO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ProductOrderPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderPage',
        'controller' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::2cuWoqfoZRW5LGrO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pyFyZXob34C6RfPM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ProductOrderData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderData',
        'controller' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::pyFyZXob34C6RfPM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5OxiMSfQGVlMKFs4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductOrderDetailsData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderDetailsData',
        'controller' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderDetailsData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5OxiMSfQGVlMKFs4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DAfQecW8g2VHb0ko' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductOrderDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderDelete',
        'controller' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::DAfQecW8g2VHb0ko',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bHtpx6hxVvZastO6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductOrderStatusEdit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderStatusEdit',
        'controller' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderStatusEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bHtpx6hxVvZastO6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::K1bB7vldOHcqJTY2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductOrderInvoiceData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderInvoiceData',
        'controller' => 'App\\Http\\Controllers\\ProductOrderController@ProductOrderInvoiceData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::K1bB7vldOHcqJTY2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cRZOnA3tHfvDEWBE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ProductReviewPage',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductReviewController@ProductReviewPage',
        'controller' => 'App\\Http\\Controllers\\ProductReviewController@ProductReviewPage',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::cRZOnA3tHfvDEWBE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fDG2K89CeK4exxg4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'ProductReviewData',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductReviewController@ProductReviewData',
        'controller' => 'App\\Http\\Controllers\\ProductReviewController@ProductReviewData',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fDG2K89CeK4exxg4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1PHpzD5xobXn7bgq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ProductReviewDelete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductReviewController@ProductReviewDelete',
        'controller' => 'App\\Http\\Controllers\\ProductReviewController@ProductReviewDelete',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::1PHpzD5xobXn7bgq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xTSYJWkY652asLiu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'smsTest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\SMSTestController@smsTest',
        'controller' => 'App\\Http\\Controllers\\SMSTestController@smsTest',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::xTSYJWkY652asLiu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Cgf6CXVbmhieZjo1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'PaymentTest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\PaymentTestController@PaymentTest',
        'controller' => 'App\\Http\\Controllers\\PaymentTestController@PaymentTest',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Cgf6CXVbmhieZjo1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jIXJUeYpzQdb5teQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'example1',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SslCommerzPaymentController@exampleEasyCheckout',
        'controller' => 'App\\Http\\Controllers\\SslCommerzPaymentController@exampleEasyCheckout',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::jIXJUeYpzQdb5teQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dFaMJX7OEA7dexhI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'example2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SslCommerzPaymentController@exampleHostedCheckout',
        'controller' => 'App\\Http\\Controllers\\SslCommerzPaymentController@exampleHostedCheckout',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dFaMJX7OEA7dexhI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dE5vjtpsag5mzKBJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SslCommerzPaymentController@index',
        'controller' => 'App\\Http\\Controllers\\SslCommerzPaymentController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dE5vjtpsag5mzKBJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CYjm6Dl0yazOj2jR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pay-via-ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SslCommerzPaymentController@payViaAjax',
        'controller' => 'App\\Http\\Controllers\\SslCommerzPaymentController@payViaAjax',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::CYjm6Dl0yazOj2jR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ogMKdjK2mVQcC1kc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'success',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SslCommerzPaymentController@success',
        'controller' => 'App\\Http\\Controllers\\SslCommerzPaymentController@success',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ogMKdjK2mVQcC1kc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RZQJGDDV549efHSC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'fail',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SslCommerzPaymentController@fail',
        'controller' => 'App\\Http\\Controllers\\SslCommerzPaymentController@fail',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::RZQJGDDV549efHSC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OGMV40z5FvxzMTH0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SslCommerzPaymentController@cancel',
        'controller' => 'App\\Http\\Controllers\\SslCommerzPaymentController@cancel',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::OGMV40z5FvxzMTH0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VCatoY85il9ajHJv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'ipn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'loginCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SslCommerzPaymentController@ipn',
        'controller' => 'App\\Http\\Controllers\\SslCommerzPaymentController@ipn',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::VCatoY85il9ajHJv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
